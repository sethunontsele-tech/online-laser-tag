/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { useEffect, useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Game } from './components/Game';
import { VoiceChat } from './components/VoiceChat';
import { useGameStore } from './store';
import { Mic, MicOff } from 'lucide-react';

function HUD() {
  const gameState = useGameStore(state => state.gameState);
  const score = useGameStore(state => state.score);
  const kills = useGameStore(state => state.kills);
  const deaths = useGameStore(state => state.deaths);
  const timeLeft = useGameStore(state => state.timeLeft);
  const health = useGameStore(state => state.health);
  const playerState = useGameStore(state => state.playerState);
  const otherPlayers = useGameStore(state => state.otherPlayers);
  const events = useGameStore(state => state.events);
  const playerCount = Object.keys(otherPlayers).length + 1;
  const leaveGame = useGameStore(state => state.leaveGame);
  const triggerEmote = useGameStore(state => state.triggerEmote);
  const isMuted = useGameStore(state => state.isMuted);
  const toggleMute = useGameStore(state => state.toggleMute);
  
  const selectedMode = useGameStore(state => state.selectedMode);
  const team = useGameStore(state => state.team);
  const teamScores = useGameStore(state => state.teamScores);
  const flags = useGameStore(state => state.flags);

  const [showScoreboard, setShowScoreboard] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        e.preventDefault();
        setShowScoreboard(true);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'Tab') {
        setShowScoreboard(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const leaderboard = useMemo(() => {
    const players = [
      { id: 'You', score: score, kills: kills, deaths: deaths, isMe: true },
      ...Object.values(otherPlayers).map(p => ({
        id: p.name,
        score: p.score,
        kills: p.kills,
        deaths: p.deaths,
        isMe: false
      }))
    ];
    return players.sort((a, b) => b.score - a.score);
  }, [score, kills, deaths, otherPlayers]);

  return (
    <>
      {/* Crosshair */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none flex flex-col items-center">
        <div className="relative">
          <div className={`w-4 h-4 border-2 rounded-full ${playerState === 'disabled' ? 'border-red-500' : 'border-cyan-400'}`} />
          <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-1 rounded-full ${playerState === 'disabled' ? 'bg-red-500' : 'bg-cyan-400'}`} />
        </div>
        <div className="mt-4 text-cyan-400/50 text-xs tracking-widest font-bold">CLICK TO AIM</div>
      </div>

      {/* HUD Left - Score & Leaderboard */}
      <div className="absolute top-4 left-4 flex flex-col gap-4 pointer-events-none">
        <div className="flex flex-col gap-1">
          <div className="text-cyan-400 text-2xl font-bold drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]">
            {selectedMode === 'ffa' ? `SCORE: ${score.toString().padStart(4, '0')}` : `TEAM: ${team.toUpperCase()}`}
          </div>
          
          {selectedMode !== 'ffa' && (
            <div className="flex gap-4 mb-2">
              <div className="flex flex-col">
                <span className="text-[10px] text-cyan-400 font-bold uppercase">Cyan</span>
                <span className="text-xl font-black text-cyan-400">{teamScores.cyan}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] text-fuchsia-400 font-bold uppercase">Fuchsia</span>
                <span className="text-xl font-black text-fuchsia-400">{teamScores.fuchsia}</span>
              </div>
            </div>
          )}

          {/* Player Health Bar */}
          <div className="w-48 h-4 bg-black/50 border border-cyan-900/50 rounded overflow-hidden">
            <div 
              className={`h-full transition-all duration-300 ${health > 50 ? 'bg-emerald-500' : health > 20 ? 'bg-amber-500' : 'bg-red-500'}`}
              style={{ width: `${health}%` }}
            />
          </div>
          <div className="text-[10px] text-cyan-400/70 font-bold tracking-widest">HEALTH: {health}%</div>
          
          {selectedMode === 'ctf' && (
            <div className="mt-4 flex flex-col gap-2">
              {flags.map(f => (
                <div key={f.team} className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${f.team === 'cyan' ? 'bg-cyan-400' : 'bg-fuchsia-400'} ${f.carrierId ? 'animate-pulse' : ''}`} />
                  <span className={`text-[10px] font-bold uppercase ${f.team === 'cyan' ? 'text-cyan-400' : 'text-fuchsia-400'}`}>
                    {f.team} Flag: {f.carrierId ? 'STOLEN' : 'AT BASE'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Leaderboard */}
        <div className="bg-black/50 border border-cyan-900/50 p-3 rounded w-48 flex flex-col gap-1">
          <div className="text-cyan-400/70 text-xs font-bold mb-1 border-b border-cyan-900/50 pb-1">LEADERBOARD</div>
          {leaderboard.map((p, i) => (
            <div key={p.id} className={`flex justify-between text-sm ${p.isMe ? 'text-cyan-400 font-bold' : 'text-cyan-400/70'}`}>
              <span>{i + 1}. {p.id}</span>
              <span>{p.score}</span>
            </div>
          ))}
        </div>
      </div>
      
      {/* HUD Right - Time, Leave, Events */}
      <div className="absolute top-4 right-4 flex flex-col items-end gap-2 pointer-events-auto">
        {gameState === 'playing' && (
          <div className="text-cyan-400 text-2xl font-bold drop-shadow-[0_0_8px_rgba(34,211,238,0.8)] pointer-events-none">
            TIME: {Math.floor(timeLeft / 60)}:{(Math.floor(timeLeft) % 60).toString().padStart(2, '0')}
          </div>
        )}
        <div className="flex gap-2">
          <button
            onClick={toggleMute}
            className={`px-3 py-1 border font-bold rounded flex items-center gap-2 transition-all ${
              isMuted 
                ? 'bg-red-500/20 border-red-500 text-red-500' 
                : 'bg-emerald-500/20 border-emerald-500 text-emerald-500'
            }`}
          >
            {isMuted ? <MicOff size={14} /> : <Mic size={14} />}
            {isMuted ? 'MUTED' : 'VOICE ON'}
          </button>
          <button
            onClick={() => triggerEmote('GG!')}
            className="px-2 py-1 bg-cyan-500/20 border border-cyan-500 text-cyan-400 text-xs font-bold rounded hover:bg-cyan-500 hover:text-black transition-all"
          >
            1: GG
          </button>
          <button
            onClick={() => triggerEmote('Nice shot!')}
            className="px-2 py-1 bg-cyan-500/20 border border-cyan-500 text-cyan-400 text-xs font-bold rounded hover:bg-cyan-500 hover:text-black transition-all"
          >
            2: NICE
          </button>
          <button
            onClick={() => triggerEmote('LOL')}
            className="px-2 py-1 bg-cyan-500/20 border border-cyan-500 text-cyan-400 text-xs font-bold rounded hover:bg-cyan-500 hover:text-black transition-all"
          >
            3: LOL
          </button>
          <button
            onClick={leaveGame}
            className="px-4 py-2 bg-red-500/20 border border-red-500 text-red-500 text-sm font-bold rounded hover:bg-red-500 hover:text-black transition-all duration-200"
          >
            LEAVE
          </button>
        </div>
        <div className="text-cyan-400/50 text-xs mt-1 pointer-events-none uppercase tracking-widest font-bold">ESC to unlock cursor</div>

        {/* Event Log */}
        <div className="mt-4 flex flex-col items-end gap-1 pointer-events-none">
          {events.slice(-5).map(event => (
            <div key={event.id} className="text-xs font-bold text-fuchsia-400 bg-black/50 px-2 py-1 rounded border border-fuchsia-900/50 animate-pulse">
              {event.message}
            </div>
          ))}
        </div>
      </div>

      {/* Multiplayer Info */}
      <div className="absolute bottom-4 left-4 flex flex-col gap-2 pointer-events-auto">
        <div className="text-cyan-400 text-sm font-bold drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]">
          PLAYERS ONLINE: {playerCount} / 60
        </div>
      </div>

      {/* Damage Overlay */}
      {playerState === 'disabled' && (
        <div className="absolute inset-0 bg-red-500/20 pointer-events-none flex items-center justify-center">
          <div className="text-red-500 text-6xl font-black tracking-widest drop-shadow-[0_0_20px_rgba(239,68,68,1)] animate-pulse">
            SYSTEM DISABLED
          </div>
        </div>
      )}

      {/* Scoreboard Overlay */}
      {showScoreboard && (
        <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50 pointer-events-none">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-zinc-900 border border-cyan-500/30 p-8 rounded-2xl w-full max-w-3xl shadow-[0_0_50px_rgba(34,211,238,0.2)]"
          >
            <div className="flex justify-between items-end mb-6 border-b border-cyan-500/20 pb-4">
              <h2 className="text-4xl font-black text-cyan-400 italic tracking-tighter">BATTLE STATS</h2>
              <div className="text-cyan-400/50 text-xs font-bold uppercase tracking-widest">Hold TAB to view</div>
            </div>

            <div className="grid grid-cols-5 gap-4 text-xs font-bold text-cyan-400/50 uppercase tracking-widest mb-4 px-4">
              <div className="col-span-2">Player</div>
              <div className="text-center">Kills</div>
              <div className="text-center">Deaths</div>
              <div className="text-right">Score</div>
            </div>

            <div className="flex flex-col gap-2 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
              {selectedMode === 'ffa' ? (
                leaderboard.map((p, i) => (
                  <div 
                    key={p.id} 
                    className={`grid grid-cols-5 gap-4 p-4 rounded-xl border transition-all ${
                      p.isMe 
                        ? 'bg-cyan-500/10 border-cyan-500/50 text-cyan-400' 
                        : 'bg-white/5 border-white/10 text-white/70'
                    }`}
                  >
                    <div className="col-span-2 flex items-center gap-3">
                      <span className="opacity-30 w-4">{i + 1}</span>
                      <span className="font-bold truncate">{p.id}</span>
                      {p.isMe && <span className="text-[8px] bg-cyan-400 text-black px-1 rounded">YOU</span>}
                    </div>
                    <div className="text-center font-mono">{p.kills}</div>
                    <div className="text-center font-mono">{p.deaths}</div>
                    <div className="text-right font-mono font-bold">{p.score}</div>
                  </div>
                ))
              ) : (
                <>
                  {/* Cyan Team */}
                  <div className="text-cyan-400 text-[10px] font-black uppercase tracking-[0.3em] mb-2 mt-4">Cyan Team</div>
                  {leaderboard.filter(p => {
                    if (p.isMe) return team === 'cyan';
                    const other = Object.values(otherPlayers).find(op => op.name === p.id);
                    return other?.team === 'cyan';
                  }).map((p, i) => (
                    <div 
                      key={p.id} 
                      className={`grid grid-cols-5 gap-4 p-4 rounded-xl border transition-all ${
                        p.isMe 
                          ? 'bg-cyan-500/20 border-cyan-500 text-cyan-400' 
                          : 'bg-cyan-500/5 border-cyan-500/20 text-cyan-400/70'
                      }`}
                    >
                      <div className="col-span-2 flex items-center gap-3">
                        <span className="opacity-30 w-4">{i + 1}</span>
                        <span className="font-bold truncate">{p.id}</span>
                        {p.isMe && <span className="text-[8px] bg-cyan-400 text-black px-1 rounded">YOU</span>}
                      </div>
                      <div className="text-center font-mono">{p.kills}</div>
                      <div className="text-center font-mono">{p.deaths}</div>
                      <div className="text-right font-mono font-bold">{p.score}</div>
                    </div>
                  ))}

                  {/* Fuchsia Team */}
                  <div className="text-fuchsia-400 text-[10px] font-black uppercase tracking-[0.3em] mb-2 mt-6">Fuchsia Team</div>
                  {leaderboard.filter(p => {
                    if (p.isMe) return team === 'fuchsia';
                    const other = Object.values(otherPlayers).find(op => op.name === p.id);
                    return other?.team === 'fuchsia';
                  }).map((p, i) => (
                    <div 
                      key={p.id} 
                      className={`grid grid-cols-5 gap-4 p-4 rounded-xl border transition-all ${
                        p.isMe 
                          ? 'bg-fuchsia-500/20 border-fuchsia-500 text-fuchsia-400' 
                          : 'bg-fuchsia-500/5 border-fuchsia-500/20 text-fuchsia-400/70'
                      }`}
                    >
                      <div className="col-span-2 flex items-center gap-3">
                        <span className="opacity-30 w-4">{i + 1}</span>
                        <span className="font-bold truncate">{p.id}</span>
                        {p.isMe && <span className="text-[8px] bg-fuchsia-400 text-black px-1 rounded">YOU</span>}
                      </div>
                      <div className="text-center font-mono">{p.kills}</div>
                      <div className="text-center font-mono">{p.deaths}</div>
                      <div className="text-right font-mono font-bold">{p.score}</div>
                    </div>
                  ))}
                </>
              )}
            </div>

            <div className="mt-8 pt-4 border-t border-cyan-500/20 flex justify-between items-center text-[10px] text-cyan-400/40 font-bold uppercase tracking-widest">
              <div>Arena: {useGameStore.getState().selectedMap}</div>
              <div>Players: {playerCount} / 60</div>
            </div>
          </motion.div>
        </div>
      )}
    </>
  );
}

function useIsMobile() {
  const [isMobile, setIsMobile] = useState(() => {
    const uaMatch = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    // Relaxed check: only block if it's definitely a small mobile device UA
    return uaMatch && window.innerWidth < 500;
  });

  useEffect(() => {
    const check = () => {
      const uaMatch = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      setIsMobile(uaMatch && window.innerWidth < 500);
    };
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  return isMobile;
}

export default function App() {
  const gameState = useGameStore(state => state.gameState);
  const score = useGameStore(state => state.score);
  const kills = useGameStore(state => state.kills);
  const deaths = useGameStore(state => state.deaths);
  const enterLobby = useGameStore(state => state.enterLobby);
  const startGame = useGameStore(state => state.startGame);
  const selectedSkin = useGameStore(state => state.selectedSkin);
  const setSkin = useGameStore(state => state.setSkin);
  const selectedMap = useGameStore(state => state.selectedMap);
  const setMap = useGameStore(state => state.setMap);
  const selectedMode = useGameStore(state => state.selectedMode);
  const setMode = useGameStore(state => state.setMode);
  const isMuted = useGameStore(state => state.isMuted);
  const toggleMute = useGameStore(state => state.toggleMute);
  const isMobile = useIsMobile();

  if (isMobile) {
    return (
      <div className="w-screen h-screen bg-black flex flex-col items-center justify-center font-mono text-center p-8">
        <div className="bg-[#0047AB] px-6 py-3 mb-8 shadow-[0_0_40px_rgba(34,211,238,0.4)]">
          <h1 className="text-4xl font-black text-white tracking-tighter italic">
            NEON ARENA
          </h1>
        </div>
        <p className="text-gray-400 text-lg mb-4">
          This game requires a keyboard and mouse to play.
        </p>
        <p className="text-cyan-400/70 text-sm mb-8">
          Please open this link on a desktop or laptop computer.
        </p>
        <button
          onClick={() => enterLobby()}
          className="px-8 py-3 border border-cyan-400 text-cyan-400 text-sm font-bold rounded hover:bg-cyan-400 hover:text-black transition-all"
        >
          BYPASS & PLAY ANYWAY
        </button>
      </div>
    );
  }

  return (
    <div className="w-screen h-screen bg-black relative overflow-hidden font-mono select-none">
      {/* 3D Canvas */}
      <div className="absolute inset-0">
        <Game />
      </div>

      {/* Voice Chat Manager */}
      <VoiceChat />

      {/* UI Overlay */}
      {gameState === 'playing' && <HUD />}

      {/* Splash Screen */}
      {gameState === 'splash' && (
        <div className="absolute inset-0 bg-black flex flex-col items-center justify-center z-20 pointer-events-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center"
          >
            <div className="relative mb-16">
              <div className="bg-[#0047AB] px-8 py-4 shadow-[0_0_60px_rgba(34,211,238,0.6)]">
                <h1 className="text-6xl font-black text-white tracking-tighter italic">
                  NEON ARENA
                </h1>
              </div>
            </div>

            <button
              onClick={enterLobby}
              className="group relative px-12 py-4 bg-transparent border-2 border-cyan-400 text-cyan-400 text-2xl font-black rounded hover:bg-cyan-400 hover:text-black transition-all duration-300 shadow-[0_0_20px_rgba(34,211,238,0.3)]"
            >
              <span className="relative z-10">INITIALIZE SYSTEM</span>
            </button>

            <div className="mt-12 flex flex-col items-center gap-2">
              <p className="text-gray-500 text-[10px] tracking-[0.3em] uppercase font-bold">
                Input detected: Keyboard & Mouse
              </p>
              <div className="flex gap-6 text-cyan-400/30 text-[9px] font-bold tracking-[0.2em] uppercase">
                <span>Multiplayer</span>
                <span>•</span>
                <span>Voice Chat</span>
                <span>•</span>
                <span>Custom Skins</span>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Menus */}
      {gameState === 'menu' && (
        <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center z-10 pointer-events-auto overflow-y-auto py-12">
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center max-w-4xl w-full px-6"
          >
            <h1 className="text-7xl font-black text-cyan-400 mb-2 drop-shadow-[0_0_30px_rgba(34,211,238,0.8)] tracking-tighter italic">
              NEON LOBBY
            </h1>
            <div className="h-1 w-32 bg-fuchsia-500 mb-8 shadow-[0_0_15px_rgba(232,121,249,0.8)]" />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 w-full">
              {/* Left Column: Customization */}
              <div className="flex flex-col gap-8">
                <section className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm">
                  <h2 className="text-xl font-bold text-cyan-400 mb-4 flex items-center gap-2">
                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                    BATTLE SKIN
                  </h2>
                  <div className="grid grid-cols-2 gap-3">
                    {(['neon', 'gold', 'stealth', 'glitch'] as const).map(skin => (
                      <button
                        key={skin}
                        onClick={() => setSkin(skin)}
                        className={`group relative overflow-hidden px-4 py-3 text-sm font-bold border-2 rounded-xl transition-all duration-300 ${
                          selectedSkin === skin 
                            ? 'bg-cyan-400 text-black border-cyan-400 scale-105 shadow-[0_0_20px_rgba(34,211,238,0.4)]' 
                            : 'bg-transparent text-cyan-400/60 border-cyan-900/30 hover:border-cyan-400/50'
                        }`}
                      >
                        {skin.toUpperCase()}
                        {selectedSkin === skin && (
                          <div className="absolute inset-0 bg-white/20 animate-pulse pointer-events-none" />
                        )}
                      </button>
                    ))}
                  </div>
                </section>

                <section className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm">
                  <h2 className="text-xl font-bold text-fuchsia-400 mb-4 flex items-center gap-2">
                    <div className="w-2 h-2 bg-fuchsia-400 rounded-full animate-pulse" />
                    BATTLE CONFIG
                  </h2>
                  <div className="flex flex-col gap-6">
                    <div>
                      <div className="text-[10px] text-fuchsia-400/50 uppercase font-bold mb-2 tracking-widest">Arena</div>
                      <div className="grid grid-cols-1 gap-2">
                        {(['maze', 'arena', 'pillars'] as const).map(map => (
                          <button
                            key={map}
                            onClick={() => setMap(map)}
                            className={`px-4 py-2 text-xs font-bold border-2 rounded-xl transition-all duration-300 text-left flex justify-between items-center ${
                              selectedMap === map 
                                ? 'bg-fuchsia-400 text-black border-fuchsia-400 shadow-[0_0_20px_rgba(232,121,249,0.4)]' 
                                : 'bg-transparent text-fuchsia-400/60 border-fuchsia-900/30 hover:border-fuchsia-400/50'
                            }`}
                          >
                            <span>{map.toUpperCase()}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-[10px] text-fuchsia-400/50 uppercase font-bold mb-2 tracking-widest">Game Mode</div>
                      <div className="grid grid-cols-1 gap-2">
                        {(['ffa', 'tdm', 'ctf'] as const).map(mode => (
                          <button
                            key={mode}
                            onClick={() => setMode(mode)}
                            className={`px-4 py-2 text-xs font-bold border-2 rounded-xl transition-all duration-300 text-left flex justify-between items-center ${
                              selectedMode === mode 
                                ? 'bg-fuchsia-400 text-black border-fuchsia-400 shadow-[0_0_20px_rgba(232,121,249,0.4)]' 
                                : 'bg-transparent text-fuchsia-400/60 border-fuchsia-900/30 hover:border-fuchsia-400/50'
                            }`}
                          >
                            <span>
                              {mode === 'ffa' && 'FREE FOR ALL'}
                              {mode === 'tdm' && 'TEAM DEATHMATCH'}
                              {mode === 'ctf' && 'CAPTURE THE FLAG'}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                  <p className="text-[10px] text-fuchsia-400/40 mt-4 italic">* Host sets config for new sessions</p>
                </section>
              </div>

              {/* Right Column: Controls & Emotes */}
              <div className="flex flex-col gap-8">
                <section className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm">
                  <h2 className="text-xl font-bold text-emerald-400 mb-4 flex items-center gap-2">
                    <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                    QUICK EMOTES
                  </h2>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { key: '1', label: 'GG!' },
                      { key: '2', label: 'NICE SHOT!' },
                      { key: '3', label: 'LOL' },
                      { key: '4', label: 'REVENGE!' },
                    ].map(emote => (
                      <div key={emote.key} className="flex items-center gap-3 bg-black/40 p-3 rounded-lg border border-emerald-900/30">
                        <span className="bg-emerald-500 text-black text-[10px] font-black px-1.5 py-0.5 rounded">{emote.key}</span>
                        <span className="text-emerald-400/80 text-xs font-bold">{emote.label}</span>
                      </div>
                    ))}
                  </div>
                </section>

                <section className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-sm">
                  <h2 className="text-xl font-bold text-amber-400 mb-4 flex items-center gap-2">
                    <div className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
                    SYSTEM CONTROLS
                  </h2>
                  <div className="grid grid-cols-2 gap-4 text-[11px] text-amber-400/70 font-bold mb-6">
                    <div className="flex flex-col gap-1">
                      <span className="text-white/40 uppercase text-[9px]">Movement</span>
                      <span>WASD / ARROWS</span>
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-white/40 uppercase text-[9px]">Jump</span>
                      <span>SPACEBAR</span>
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-white/40 uppercase text-[9px]">Fire Laser</span>
                      <span>LEFT CLICK</span>
                    </div>
                    <div className="flex flex-col gap-1">
                      <span className="text-white/40 uppercase text-[9px]">Unlock Mouse</span>
                      <span>ESC KEY</span>
                    </div>
                  </div>

                  <button
                    onClick={toggleMute}
                    className={`w-full py-3 border-2 font-bold rounded-xl flex items-center justify-center gap-3 transition-all ${
                      isMuted 
                        ? 'bg-red-500/10 border-red-500/50 text-red-500 hover:bg-red-500/20' 
                        : 'bg-emerald-500/10 border-emerald-500/50 text-emerald-500 hover:bg-emerald-500/20'
                    }`}
                  >
                    {isMuted ? <MicOff size={18} /> : <Mic size={18} />}
                    {isMuted ? 'MICROPHONE: MUTED' : 'MICROPHONE: ACTIVE'}
                  </button>
                </section>

                <button
                  onClick={() => startGame()}
                  className="mt-auto w-full group relative overflow-hidden px-8 py-6 bg-fuchsia-500 text-black text-2xl font-black rounded-2xl hover:bg-fuchsia-400 transition-all duration-300 transform hover:scale-[1.02] active:scale-95 shadow-[0_0_30px_rgba(232,121,249,0.6)]"
                >
                  <span className="relative z-10">INITIALIZE BATTLE</span>
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {gameState === 'gameover' && (
        <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center z-30 pointer-events-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center max-w-2xl w-full px-6"
          >
            <h1 className="text-7xl font-black text-red-500 mb-2 drop-shadow-[0_0_30px_rgba(239,68,68,0.6)] tracking-tighter italic">
              BATTLE ENDED
            </h1>
            <div className="h-1 w-24 bg-red-500 mb-12 shadow-[0_0_15px_rgba(239,68,68,0.8)]" />

            <div className="grid grid-cols-3 gap-8 w-full mb-12">
              <div className="bg-white/5 border border-white/10 p-6 rounded-2xl text-center backdrop-blur-sm">
                <div className="text-white/40 text-[10px] uppercase font-bold tracking-widest mb-1">Total Score</div>
                <div className="text-4xl font-black text-cyan-400">{score}</div>
              </div>
              <div className="bg-white/5 border border-white/10 p-6 rounded-2xl text-center backdrop-blur-sm">
                <div className="text-white/40 text-[10px] uppercase font-bold tracking-widest mb-1">Kills</div>
                <div className="text-4xl font-black text-emerald-400">{kills}</div>
              </div>
              <div className="bg-white/5 border border-white/10 p-6 rounded-2xl text-center backdrop-blur-sm">
                <div className="text-white/40 text-[10px] uppercase font-bold tracking-widest mb-1">Deaths</div>
                <div className="text-4xl font-black text-red-400">{deaths}</div>
              </div>
            </div>

            <button
              onClick={() => startGame()}
              className="w-full group relative overflow-hidden px-8 py-6 bg-cyan-500 text-black text-2xl font-black rounded-2xl hover:bg-cyan-400 transition-all duration-300 transform hover:scale-[1.02] active:scale-95 shadow-[0_0_30px_rgba(34,211,238,0.6)]"
            >
              RE-INITIALIZE SYSTEM
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
