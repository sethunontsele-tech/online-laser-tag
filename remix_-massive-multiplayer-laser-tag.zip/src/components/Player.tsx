/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { useRef, useEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { RigidBody, RapierRigidBody, useRapier, CapsuleCollider } from '@react-three/rapier';
import { PointerLockControls } from '@react-three/drei';
import * as THREE from 'three';
import { useGameStore } from '../store';

const SPEED = 12;
const MAX_LASER_DIST = 100;

export function Player() {
  const body = useRef<RapierRigidBody>(null);
  const { camera } = useThree();
  const { rapier, world } = useRapier();
  
  const playerState = useGameStore(state => state.playerState);
  const gameState = useGameStore(state => state.gameState);
  const addLaser = useGameStore(state => state.addLaser);
  const hitEnemy = useGameStore(state => state.hitEnemy);
  const addParticles = useGameStore(state => state.addParticles);

  const keys = useRef({ w: false, a: false, s: false, d: false, space: false });
  const lastEmitTime = useRef(0);
  const isGrounded = useRef(false);

  const gunGroupRef = useRef<THREE.Group>(null);
  const gunVisualRef = useRef<THREE.Group>(null);
  const gunBarrelRef = useRef<THREE.Group>(null);

  const selectedSkin = useGameStore(state => state.selectedSkin);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (key === ' ') keys.current.space = true;
      if (key in keys.current) keys.current[key as keyof typeof keys.current] = true;
      
      // Emotes
      if (e.key === '1') useGameStore.getState().triggerEmote('GG!');
      if (e.key === '2') useGameStore.getState().triggerEmote('Nice shot!');
      if (e.key === '3') useGameStore.getState().triggerEmote('LOL');
      if (e.key === '4') useGameStore.getState().triggerEmote('REVENGE!');
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (key === ' ') keys.current.space = false;
      if (key in keys.current) keys.current[key as keyof typeof keys.current] = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const updatePlayerPosition = useGameStore(state => state.updatePlayerPosition);

  useFrame((_, delta) => {
    if (!body.current || gameState !== 'playing') return;

    // Movement
    const velocity = body.current.linvel();
    
    const k = keys.current;
    
    const forward = new THREE.Vector3();
    camera.getWorldDirection(forward);
    forward.y = 0;
    forward.normalize();

    const right = new THREE.Vector3();
    right.crossVectors(forward, camera.up).normalize();

    const moveZ = (k.w ? 1 : 0) - (k.s ? 1 : 0);
    const moveX = (k.d ? 1 : 0) - (k.a ? 1 : 0);

    const direction = new THREE.Vector3();
    direction.addScaledVector(forward, moveZ);
    direction.addScaledVector(right, moveX);
    
    if (direction.lengthSq() > 0) {
      direction.normalize().multiplyScalar(SPEED);
    }

    // Update camera position to follow rigid body
    const pos = body.current.translation();
    camera.position.set(pos.x, pos.y + 0.8, pos.z); // Eye level

    // Ground check
    const rayStart = new THREE.Vector3(pos.x, pos.y + 0.1, pos.z);
    const rayDir = new THREE.Vector3(0, -1, 0);
    const ray = new rapier.Ray(rayStart, rayDir);
    const hit = world.castRay(ray, 0.5, true);
    isGrounded.current = !!hit;

    // Jump
    let jumpVel = velocity.y;
    if (k.space && isGrounded.current) {
      jumpVel = 10;
    }

    body.current.setLinvel({ x: direction.x, y: jumpVel, z: direction.z }, true);

    // Sync gun to camera
    if (gunGroupRef.current) {
      gunGroupRef.current.position.copy(camera.position);
      gunGroupRef.current.quaternion.copy(camera.quaternion);
    }
    
    // Recover recoil
    if (gunVisualRef.current) {
      gunVisualRef.current.position.z = THREE.MathUtils.lerp(gunVisualRef.current.position.z, -0.6, delta * 15);
      gunVisualRef.current.rotation.x = THREE.MathUtils.lerp(gunVisualRef.current.rotation.x, 0, delta * 15);
    }

    // Emit position to server
    const now = Date.now();
    if (now - lastEmitTime.current > 50) {
      updatePlayerPosition([pos.x, pos.y, pos.z], camera.rotation.y);
      lastEmitTime.current = now;
    }
  });

  useEffect(() => {
    const handleClick = () => {
      if (document.pointerLockElement && gameState === 'playing' && playerState === 'active') {
        // Raycast from camera
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);

        // Start raycast slightly ahead of the camera to avoid hitting the player's own collider
        const rayStart = camera.position.clone().add(raycaster.ray.direction.clone().multiplyScalar(0.8));
        const ray = new rapier.Ray(rayStart, raycaster.ray.direction);
        const hit = world.castRay(ray, MAX_LASER_DIST, true);

        const startPosVec = new THREE.Vector3();
        if (gunBarrelRef.current) {
          gunBarrelRef.current.getWorldPosition(startPosVec);
        } else {
          startPosVec.copy(camera.position);
        }
        const startPos: [number, number, number] = [startPosVec.x, startPosVec.y, startPosVec.z];

        // Apply recoil
        if (gunVisualRef.current) {
          gunVisualRef.current.position.z = -0.4;
          gunVisualRef.current.rotation.x = 0.1;
        }

        let endPos: [number, number, number];

        if (hit) {
          const hitPoint = ray.pointAt(hit.timeOfImpact);
          endPos = [hitPoint.x, hitPoint.y, hitPoint.z];
          
          const collider = hit.collider;
          const rb = collider.parent();
          if (rb && rb.userData) {
            const userData = rb.userData as { name?: string };
            if (userData.name && userData.name.startsWith('bot-')) {
              hitEnemy(userData.name, true);
            } else if (userData.name && userData.name !== 'player' && !userData.name.startsWith('obstacle') && !userData.name.startsWith('wall') && userData.name !== 'floor' && userData.name !== 'ceiling') {
              // Hit another player
              hitEnemy(userData.name, true);
            }
          }
          
          addParticles(endPos, '#00ffff');
        } else {
          endPos = [
            camera.position.x + raycaster.ray.direction.x * MAX_LASER_DIST,
            camera.position.y + raycaster.ray.direction.y * MAX_LASER_DIST,
            camera.position.z + raycaster.ray.direction.z * MAX_LASER_DIST
          ];
        }

        addLaser(startPos, endPos, '#00ffff');
      }
    };
    window.addEventListener('mousedown', handleClick);
    return () => window.removeEventListener('mousedown', handleClick);
  }, [gameState, playerState, camera, world, rapier, hitEnemy, addParticles, addLaser]);

  return (
    <>
      <PointerLockControls />
      <RigidBody
        ref={body}
        colliders={false}
        mass={1}
        type="dynamic"
        position={[0, 2, 0]}
        enabledRotations={[false, false, false]}
        userData={{ name: 'player' }}
        friction={0}
      >
        <CapsuleCollider args={[0.5, 0.2]} position={[0, 0.7, 0]} friction={0} />
      </RigidBody>

      {/* First Person Gun */}
      <group ref={gunGroupRef}>
        <group ref={gunVisualRef} position={[0.4, -0.3, -0.6]}>
          {/* Main body */}
          <mesh position={[0, 0, 0.2]}>
            <boxGeometry args={[0.1, 0.15, 0.4]} />
            <meshStandardMaterial 
              color={selectedSkin === 'gold' ? '#ffd700' : (selectedSkin === 'stealth' ? '#111' : '#222')} 
              metalness={selectedSkin === 'gold' ? 1 : 0.8} 
              roughness={selectedSkin === 'gold' ? 0.1 : 0.2} 
            />
          </mesh>
          {/* Barrel */}
          <mesh position={[0, 0.05, -0.15]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.03, 0.03, 0.3, 8]} />
            <meshStandardMaterial 
              color={selectedSkin === 'gold' ? '#fff' : (selectedSkin === 'stealth' ? '#000' : '#111')} 
              metalness={0.9} 
              roughness={0.1} 
            />
          </mesh>
          {/* Neon accents */}
          <mesh position={[0, 0.08, 0.1]}>
            <boxGeometry args={[0.11, 0.02, 0.2]} />
            <meshBasicMaterial color={selectedSkin === 'gold' ? '#fff' : (selectedSkin === 'neon' ? '#00ffff' : '#ff00ff')} toneMapped={false} />
          </mesh>
          <mesh position={[0, 0.05, -0.25]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.035, 0.035, 0.05, 8]} />
            <meshBasicMaterial color={selectedSkin === 'gold' ? '#ff00ff' : (selectedSkin === 'neon' ? '#ff00ff' : '#00ffff')} toneMapped={false} />
          </mesh>
          {/* Barrel Tip Reference */}
          <group ref={gunBarrelRef} position={[0, 0.05, -0.3]} />
        </group>
      </group>
    </>
  );
}
