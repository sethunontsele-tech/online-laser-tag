/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import { create } from 'zustand';
import * as THREE from 'three';
import { io, Socket } from 'socket.io-client';

export type GameState = 'splash' | 'menu' | 'playing' | 'gameover';
export type EntityState = 'active' | 'disabled';
export type MapType = 'maze' | 'arena' | 'pillars';
export type SkinType = 'neon' | 'gold' | 'stealth' | 'glitch';
export type GameMode = 'ffa' | 'tdm' | 'ctf';
export type Team = 'none' | 'cyan' | 'fuchsia';

export interface EnemyData {
  id: string;
  position: [number, number, number];
  state: EntityState;
  disabledUntil: number;
  health: number;
  team: Team;
}

export interface PlayerData {
  id: string;
  name: string;
  position: [number, number, number];
  rotation: number;
  state: EntityState;
  disabledUntil: number;
  score: number;
  color: string;
  skin: SkinType;
  health: number;
  kills: number;
  deaths: number;
  team: Team;
}

export interface FlagData {
  team: Team;
  position: [number, number, number];
  carrierId: string | null; // null if at base or dropped
}

export interface LaserData {
  id: string;
  start: [number, number, number];
  end: [number, number, number];
  timestamp: number;
  color: string;
}

export interface ParticleData {
  id: string;
  position: [number, number, number];
  timestamp: number;
  color: string;
}

export interface GameEvent {
  id: string;
  message: string;
  timestamp: number;
}

interface GameStore {
  gameState: GameState;
  score: number;
  timeLeft: number;
  health: number;
  kills: number;
  deaths: number;
  playerState: EntityState;
  playerDisabledUntil: number;
  enemies: EnemyData[];
  lasers: LaserData[];
  particles: ParticleData[];
  events: GameEvent[];
  
  // Multiplayer
  socket: Socket | null;
  otherPlayers: Record<string, PlayerData>;
  
  selectedSkin: SkinType;
  selectedMap: MapType;
  selectedMode: GameMode;
  isMuted: boolean;
  
  team: Team;
  teamScores: { cyan: number; fuchsia: number };
  flags: FlagData[];

  enterLobby: () => void;
  startGame: () => void;
  endGame: () => void;
  leaveGame: () => void;
  updateTime: (delta: number) => void;
  hitPlayer: () => void;
  hitEnemy: (id: string, byPlayer?: boolean) => void;
  addLaser: (start: [number, number, number], end: [number, number, number], color: string) => void;
  addParticles: (position: [number, number, number], color: string) => void;
  addEvent: (message: string) => void;
  updateEnemies: (time: number) => void;
  cleanupEffects: (time: number) => void;
  setPlayerState: (state: EntityState) => void;
  setSkin: (skin: SkinType) => void;
  setMap: (map: MapType) => void;
  setMode: (mode: GameMode) => void;
  triggerEmote: (emote: string) => void;
  toggleMute: () => void;
  
  // Multiplayer actions
  updatePlayerPosition: (position: [number, number, number], rotation: number) => void;
}

const INITIAL_ENEMIES: EnemyData[] = [
  { id: 'bot-1', position: [40, 1, 40], state: 'active', disabledUntil: 0, health: 100, team: 'none' },
  { id: 'bot-2', position: [-40, 1, 40], state: 'active', disabledUntil: 0, health: 100, team: 'none' },
  { id: 'bot-3', position: [40, 1, -40], state: 'active', disabledUntil: 0, health: 100, team: 'none' },
  { id: 'bot-4', position: [-40, 1, -40], state: 'active', disabledUntil: 0, health: 100, team: 'none' },
  { id: 'bot-5', position: [0, 1, -50], state: 'active', disabledUntil: 0, health: 100, team: 'none' },
  { id: 'bot-6', position: [60, 1, 0], state: 'active', disabledUntil: 0, health: 100, team: 'none' },
  { id: 'bot-7', position: [-60, 1, 0], state: 'active', disabledUntil: 0, health: 100, team: 'none' },
  { id: 'bot-8', position: [0, 1, 50], state: 'active', disabledUntil: 0, health: 100, team: 'none' },
];

export const useGameStore = create<GameStore>((set, get) => ({
  gameState: 'splash',
  score: 0,
  timeLeft: 120, // 2 minutes
  health: 100,
  kills: 0,
  deaths: 0,
  playerState: 'active',
  playerDisabledUntil: 0,
  enemies: [],
  lasers: [],
  particles: [],
  events: [],
  
  socket: null,
  otherPlayers: {},
  selectedSkin: 'neon',
  selectedMap: 'maze',
  selectedMode: 'ffa',
  isMuted: true,
  
  team: 'none',
  teamScores: { cyan: 0, fuchsia: 0 },
  flags: [],

  enterLobby: () => set({ gameState: 'menu' }),

  startGame: () => {
    const { socket, selectedSkin, selectedMap, selectedMode } = get();
    
    if (socket) {
      socket.disconnect();
    }

    let newSocket: Socket | null = null;

    // Initialize multiplayer
    newSocket = io(window.location.origin);
    
    newSocket.on('connect', () => {
      newSocket!.emit('joinGame', { skin: selectedSkin, map: selectedMap, mode: selectedMode });
    });

    newSocket.on('gameError', (msg: string) => {
      alert(msg);
      get().leaveGame();
    });

    newSocket.on('gameJoined', (data: { players: Record<string, PlayerData>, team: Team, mode: GameMode, flags: FlagData[] }) => {
      const otherPlayers = { ...data.players };
      delete otherPlayers[newSocket!.id!];
      set({ 
        otherPlayers,
        gameState: 'playing',
        timeLeft: 120,
        score: 0,
        health: 100,
        kills: 0,
        deaths: 0,
        team: data.team,
        selectedMode: data.mode,
        flags: data.flags,
        enemies: INITIAL_ENEMIES.map(e => ({ ...e, state: 'active', disabledUntil: 0, health: 100, team: 'none' }))
      });
    });

      newSocket.on('playerJoined', (player: PlayerData) => {
        set(state => ({
          otherPlayers: { ...state.otherPlayers, [player.id]: player },
          events: [...state.events, { id: Math.random().toString(), message: `${player.name} joined`, timestamp: Date.now() }]
        }));
      });

      newSocket.on('playerMoved', (data: { id: string, position: [number, number, number], rotation: number }) => {
        set(state => {
          if (!state.otherPlayers[data.id]) return state;
          return {
            otherPlayers: {
              ...state.otherPlayers,
              [data.id]: {
                ...state.otherPlayers[data.id],
                position: data.position,
                rotation: data.rotation
              }
            }
          };
        });
      });

      newSocket.on('playerShot', (data: { id: string, start: [number, number, number], end: [number, number, number], color: string }) => {
        set(state => ({
          lasers: [...state.lasers, { id: Math.random().toString(36).substr(2, 9), start: data.start, end: data.end, timestamp: Date.now(), color: data.color }],
          particles: [...state.particles, { id: Math.random().toString(36).substr(2, 9), position: data.end, timestamp: Date.now(), color: data.color }]
        }));
      });

      newSocket.on('playerHit', (data: { targetId: string, shooterId: string, targetDisabledUntil: number, shooterScore: number, targetHealth: number, shooterKills: number, targetDeaths: number }) => {
        set(state => {
          const now = Date.now();
          const shooterName = data.shooterId === newSocket!.id ? 'You' : (state.otherPlayers[data.shooterId]?.name || 'Unknown');
          const targetName = data.targetId === newSocket!.id ? 'You' : (state.otherPlayers[data.targetId]?.name || 'Unknown');
          
          if (data.targetId === newSocket!.id) {
            const isDead = data.targetHealth <= 0;
            const eventMsg = isDead ? `${shooterName} eliminated ${targetName}` : `${shooterName} hit ${targetName}`;
            const newEvent = { id: Math.random().toString(), message: eventMsg, timestamp: now };
            
            return {
              playerState: isDead ? 'disabled' : 'active',
              playerDisabledUntil: data.targetDisabledUntil,
              health: data.targetHealth,
              deaths: data.targetDeaths,
              events: [...state.events, newEvent]
            };
          } else {
            const players = { ...state.otherPlayers };
            const isDead = data.targetHealth <= 0;
            const eventMsg = isDead ? `${shooterName} eliminated ${targetName}` : `${shooterName} hit ${targetName}`;
            const newEvent = { id: Math.random().toString(), message: eventMsg, timestamp: now };

            if (players[data.targetId]) {
              players[data.targetId] = {
                ...players[data.targetId],
                state: isDead ? 'disabled' : 'active',
                disabledUntil: data.targetDisabledUntil,
                health: data.targetHealth,
                deaths: data.targetDeaths
              };
            }
            if (players[data.shooterId]) {
              players[data.shooterId] = {
                ...players[data.shooterId],
                score: data.shooterScore,
                kills: data.shooterKills
              };
            }
            
            // If I am the shooter, update my kills too (though server usually handles score, kills is good to sync)
            if (data.shooterId === newSocket!.id) {
              return { 
                score: data.shooterScore,
                kills: data.shooterKills,
                otherPlayers: players, 
                events: [...state.events, newEvent] 
              };
            }

            return { otherPlayers: players, events: [...state.events, newEvent] };
          }
        });
      });

      newSocket.on('playerLeft', (id: string) => {
        set(state => {
          const players = { ...state.otherPlayers };
          const playerName = players[id]?.name || 'Unknown';
          delete players[id];
          return { 
            otherPlayers: players,
            events: [...state.events, { id: Math.random().toString(), message: `${playerName} left`, timestamp: Date.now() }]
          };
        });
      });

      newSocket.on('emote', (data: { id: string, emote: string }) => {
        set(state => {
          const playerName = data.id === newSocket!.id ? 'You' : (state.otherPlayers[data.id]?.name || 'Unknown');
          return {
            events: [...state.events, { id: Math.random().toString(), message: `${playerName}: ${data.emote}`, timestamp: Date.now() }]
          };
        });
      });

      newSocket.on('teamScores', (scores: { cyan: number, fuchsia: number }) => {
        set({ teamScores: scores });
      });

      newSocket.on('flagUpdate', (flags: FlagData[]) => {
        set({ flags });
      });

      newSocket.on('flagEvent', (data: { message: string }) => {
        set(state => ({
          events: [...state.events, { id: Math.random().toString(), message: data.message, timestamp: Date.now() }]
        }));
      });

      newSocket.on('mapChanged', (map: MapType) => {
        set({ selectedMap: map });
      });
    set({
      gameState: 'playing',
      score: 0,
      timeLeft: 120,
      playerState: 'active',
      playerDisabledUntil: 0,
      health: 100,
      kills: 0,
      deaths: 0,
      enemies: INITIAL_ENEMIES.map(e => ({ ...e, state: 'active', disabledUntil: 0, health: 100 })),
      lasers: [],
      particles: [],
      events: [],
      socket: newSocket,
      otherPlayers: {},
    });
  },

  endGame: () => {
    const { socket } = get();
    if (socket) {
      socket.disconnect();
    }
    set({ gameState: 'gameover', socket: null });
  },

  leaveGame: () => {
    const { socket } = get();
    if (socket) {
      socket.disconnect();
    }
    set({
      gameState: 'menu',
      socket: null,
      otherPlayers: {},
      enemies: [],
      lasers: [],
      particles: [],
      events: [],
      score: 0,
      timeLeft: 120,
      playerState: 'active'
    });
  },

  updateTime: (delta) => set((state) => {
    if (state.gameState !== 'playing') return state;
    const newTime = state.timeLeft - delta;
    if (newTime <= 0) {
      if (state.socket) state.socket.disconnect();
      return { timeLeft: 0, gameState: 'gameover', socket: null, roomId: null };
    }
    return { timeLeft: newTime };
  }),

  hitPlayer: () => set((state) => {
    if (state.playerState === 'disabled' || state.gameState !== 'playing') return state;
    const newHealth = Math.max(0, state.health - 20);
    const isDead = newHealth <= 0;
    return {
      health: newHealth,
      playerState: isDead ? 'disabled' : 'active',
      playerDisabledUntil: isDead ? Date.now() + 3000 : 0,
      deaths: isDead ? state.deaths + 1 : state.deaths,
      score: Math.max(0, state.score - 10), // Small penalty for getting hit
    };
  }),

  hitEnemy: (id, byPlayer = false) => set((state) => {
    if (state.gameState !== 'playing') return state;
    
    // Check if it's a multiplayer player
    if (state.socket && state.otherPlayers[id]) {
      state.socket.emit('hitPlayer', id);
      return state;
    }

    let enemyHit = false;
    const enemies = state.enemies.map(e => {
      if (e.id === id && e.state === 'active') {
        enemyHit = true;
        const newHealth = Math.max(0, e.health - 25);
        const isDead = newHealth <= 0;
        return { 
          ...e, 
          health: newHealth,
          state: isDead ? 'disabled' as EntityState : 'active' as EntityState, 
          disabledUntil: isDead ? Date.now() + 3000 : 0 
        };
      }
      return e;
    });

    if (!enemyHit) return state;

    const hitEnemyObj = enemies.find(e => e.id === id);
    const isDead = hitEnemyObj?.health === 0;

    return {
      enemies,
      kills: byPlayer && isDead ? state.kills + 1 : state.kills,
      score: byPlayer ? (isDead ? state.score + 100 : state.score + 20) : state.score,
      events: byPlayer && isDead ? [...state.events, { id: Math.random().toString(), message: `You eliminated ${id}`, timestamp: Date.now() }] : state.events
    };
  }),

  addLaser: (start, end, color) => {
    const { socket } = get();
    if (socket) {
      socket.emit('shoot', { start, end, color });
    }
    set((state) => ({
      lasers: [...state.lasers, { id: Math.random().toString(36).substr(2, 9), start, end, timestamp: Date.now(), color }]
    }));
  },

  addParticles: (position, color) => set((state) => ({
    particles: [...state.particles, { id: Math.random().toString(36).substr(2, 9), position, timestamp: Date.now(), color }]
  })),

  addEvent: (message) => set((state) => ({
    events: [...state.events, { id: Math.random().toString(), message, timestamp: Date.now() }]
  })),

  updateEnemies: (time) => set((state) => {
    let changed = false;
    const enemies = state.enemies.map(e => {
      if (e.state === 'disabled' && time > e.disabledUntil) {
        changed = true;
        return { ...e, state: 'active' as EntityState, health: 100 };
      }
      return e;
    });
    
    // Also update other players' states
    let otherPlayers = state.otherPlayers;
    let playersChanged = false;
    Object.values(state.otherPlayers).forEach(p => {
      if (p.state === 'disabled' && time > p.disabledUntil) {
        if (!playersChanged) {
          otherPlayers = { ...state.otherPlayers };
          playersChanged = true;
        }
        otherPlayers[p.id] = { ...p, state: 'active', health: 100 };
      }
    });

    if (state.playerState === 'disabled' && time > state.playerDisabledUntil) {
      return { enemies, playerState: 'active', health: 100, otherPlayers: playersChanged ? otherPlayers : state.otherPlayers };
    }
    return changed || playersChanged ? { enemies, otherPlayers } : state;
  }),

  cleanupEffects: (time) => set((state) => {
    const lasers = state.lasers.filter(l => time - l.timestamp < 200); // Lasers last 200ms
    const particles = state.particles.filter(p => time - p.timestamp < 500); // Particles last 500ms
    const events = state.events.filter(e => time - e.timestamp < 5000); // Events last 5s
    if (lasers.length !== state.lasers.length || particles.length !== state.particles.length || events.length !== state.events.length) {
      return { lasers, particles, events };
    }
    return state;
  }),

  setPlayerState: (playerState) => set({ playerState }),

  setSkin: (selectedSkin) => set({ selectedSkin }),
  setMap: (selectedMap) => set({ selectedMap }),
  setMode: (selectedMode) => set({ selectedMode }),

  triggerEmote: (emote) => {
    const { socket } = get();
    if (socket) {
      socket.emit('emote', emote);
    }
  },

  toggleMute: () => set(state => ({ isMuted: !state.isMuted })),

  updatePlayerPosition: (position, rotation) => {
    const { socket } = get();
    if (socket) {
      socket.emit('updatePosition', { position, rotation });
    }
  }
}));
