/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import express from 'express';
import { createServer as createViteServer } from 'vite';
import { createServer } from 'http';
import { Server } from 'socket.io';
import path from 'path';

async function startServer() {
  const app = express();
  const PORT = 3000;
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: '*',
    },
  });

  // Global Game State
  const MAX_PLAYERS = 60;
  let playerCounter = 1;
  let currentMap: 'maze' | 'arena' | 'pillars' = 'maze';
  let currentMode: 'ffa' | 'tdm' | 'ctf' = 'ffa';
  
  const teamScores = { cyan: 0, fuchsia: 0 };
  const flags = [
    { team: 'cyan' as const, position: [0, 0, 80] as [number, number, number], carrierId: null as string | null },
    { team: 'fuchsia' as const, position: [0, 0, -80] as [number, number, number], carrierId: null as string | null }
  ];

  const players: Record<string, { 
    id: string, 
    name: string, 
    position: [number, number, number], 
    rotation: number, 
    state: 'active' | 'disabled', 
    disabledUntil: number, 
    score: number, 
    color: string, 
    skin: string, 
    health: number, 
    kills: number, 
    deaths: number,
    team: 'none' | 'cyan' | 'fuchsia'
  }> = {};

  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('joinGame', (data: { skin: string, map: 'maze' | 'arena' | 'pillars', mode: 'ffa' | 'tdm' | 'ctf' }) => {
      if (Object.keys(players).length >= MAX_PLAYERS) {
        socket.emit('gameError', 'Server is full (60/60 players)');
        return;
      }
      
      // If it's the first player, they set the map and mode
      if (Object.keys(players).length === 0) {
        if (data.map) currentMap = data.map;
        if (data.mode) currentMode = data.mode;
      }
      
      const playerName = `Player ${playerCounter++}`;

      // Assign team
      let team: 'none' | 'cyan' | 'fuchsia' = 'none';
      if (currentMode !== 'ffa') {
        const cyanCount = Object.values(players).filter(p => p.team === 'cyan').length;
        const fuchsiaCount = Object.values(players).filter(p => p.team === 'fuchsia').length;
        team = cyanCount <= fuchsiaCount ? 'cyan' : 'fuchsia';
      }

      const color = team === 'cyan' ? '#00ffff' : (team === 'fuchsia' ? '#ff00ff' : '#00ffff');

      players[socket.id] = {
        id: socket.id,
        name: playerName,
        position: [0, 2, 0],
        rotation: 0,
        state: 'active',
        disabledUntil: 0,
        score: 0,
        color,
        skin: data.skin || 'neon',
        health: 100,
        kills: 0,
        deaths: 0,
        team
      };

      // Send initial state
      socket.emit('gameJoined', { 
        players, 
        team, 
        mode: currentMode,
        flags: currentMode === 'ctf' ? flags : []
      });
      socket.emit('mapChanged', currentMap);
      
      if (currentMode !== 'ffa') {
        socket.emit('teamScores', teamScores);
      }

      // Broadcast to others
      socket.broadcast.emit('playerJoined', players[socket.id]);
    });

    socket.on('updatePosition', (data: { position: [number, number, number], rotation: number }) => {
      if (players[socket.id]) {
        players[socket.id].position = data.position;
        players[socket.id].rotation = data.rotation;
        socket.broadcast.emit('playerMoved', { id: socket.id, ...data });

        // CTF Flag Logic
        if (currentMode === 'ctf') {
          flags.forEach(flag => {
            if (flag.carrierId === socket.id) {
              flag.position = [data.position[0], data.position[1] + 1, data.position[2]];
              io.emit('flagUpdate', flags);

              // Check for capture
              const myBasePos = players[socket.id].team === 'cyan' ? [0, 0, 80] : [0, 0, -80];
              
              // If carrying enemy flag and reach my base
              if (flag.team !== players[socket.id].team) {
                const distToBase = Math.sqrt(
                  Math.pow(data.position[0] - myBasePos[0], 2) +
                  Math.pow(data.position[2] - myBasePos[2], 2)
                );

                if (distToBase < 5) {
                  // Capture!
                  const team = players[socket.id].team as 'cyan' | 'fuchsia';
                  teamScores[team] += 1;
                  flag.carrierId = null;
                  flag.position = flag.team === 'cyan' ? [0, 0, 80] : [0, 0, -80];
                  io.emit('teamScores', teamScores);
                  io.emit('flagUpdate', flags);
                  io.emit('flagEvent', { message: `${players[socket.id].name} captured the ${flag.team} flag!` });
                  players[socket.id].score += 500;
                }
              }
            } else if (flag.carrierId === null) {
              // Check for pickup
              const distToFlag = Math.sqrt(
                Math.pow(data.position[0] - flag.position[0], 2) +
                Math.pow(data.position[2] - flag.position[2], 2)
              );

              if (distToFlag < 2 && players[socket.id].state === 'active') {
                // If it's enemy flag, pick it up
                if (flag.team !== players[socket.id].team) {
                  flag.carrierId = socket.id;
                  io.emit('flagUpdate', flags);
                  io.emit('flagEvent', { message: `${players[socket.id].name} picked up the ${flag.team} flag!` });
                } else {
                  // If it's my flag and it's dropped, return it
                  const basePos = flag.team === 'cyan' ? [0, 0, 80] : [0, 0, -80];
                  const distToBase = Math.sqrt(
                    Math.pow(flag.position[0] - basePos[0], 2) +
                    Math.pow(flag.position[2] - basePos[2], 2)
                  );
                  if (distToBase > 5) {
                    flag.position = basePos as [number, number, number];
                    io.emit('flagUpdate', flags);
                    io.emit('flagEvent', { message: `${players[socket.id].name} returned the ${flag.team} flag!` });
                  }
                }
              }
            }
          });
        }
      }
    });

    socket.on('shoot', (data: { start: [number, number, number], end: [number, number, number], color: string }) => {
      socket.broadcast.emit('playerShot', { id: socket.id, ...data });
    });

    socket.on('hitPlayer', (targetId: string) => {
      if (players[targetId] && players[socket.id]) {
        // Friendly fire check
        if (currentMode !== 'ffa' && players[targetId].team === players[socket.id].team) {
          return;
        }

        if (players[targetId].state === 'active') {
          players[targetId].health = Math.max(0, players[targetId].health - 20);
          
          if (players[targetId].health <= 0) {
            players[targetId].state = 'disabled';
            players[targetId].disabledUntil = Date.now() + 3000;
            players[targetId].deaths += 1;
            players[socket.id].score += 100;
            players[socket.id].kills += 1;

            if (currentMode !== 'ffa') {
              const team = players[socket.id].team as 'cyan' | 'fuchsia';
              teamScores[team] += 10;
              io.emit('teamScores', teamScores);
            }

            // Drop flag if carrying
            if (currentMode === 'ctf') {
              flags.forEach(flag => {
                if (flag.carrierId === targetId) {
                  flag.carrierId = null;
                  io.emit('flagUpdate', flags);
                  io.emit('flagEvent', { message: `${players[targetId].name} dropped the ${flag.team} flag!` });
                }
              });
            }
            
            // Auto-respawn logic on server side
            setTimeout(() => {
              if (players[targetId]) {
                players[targetId].state = 'active';
                players[targetId].health = 100;
              }
            }, 3000);
          } else {
            players[socket.id].score += 20;
          }
          
          io.emit('playerHit', {
            targetId,
            shooterId: socket.id,
            targetDisabledUntil: players[targetId].disabledUntil,
            shooterScore: players[socket.id].score,
            targetHealth: players[targetId].health,
            shooterKills: players[socket.id].kills,
            targetDeaths: players[targetId].deaths
          });
        }
      }
    });

    socket.on('emote', (emote: string) => {
      if (players[socket.id]) {
        io.emit('emote', { id: socket.id, emote });
      }
    });

    // WebRTC Signaling
    socket.on('signal', (data: { to: string, signal: any }) => {
      io.to(data.to).emit('signal', { from: socket.id, signal: data.signal });
    });

    socket.on('disconnect', () => {
      if (players[socket.id]) {
        // Drop flag if carrying
        if (currentMode === 'ctf') {
          flags.forEach(flag => {
            if (flag.carrierId === socket.id) {
              flag.carrierId = null;
              io.emit('flagUpdate', flags);
            }
          });
        }

        delete players[socket.id];
        io.emit('playerLeft', socket.id);
      }
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (req, res) => {
      res.sendFile(path.join(process.cwd(), 'dist', 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();